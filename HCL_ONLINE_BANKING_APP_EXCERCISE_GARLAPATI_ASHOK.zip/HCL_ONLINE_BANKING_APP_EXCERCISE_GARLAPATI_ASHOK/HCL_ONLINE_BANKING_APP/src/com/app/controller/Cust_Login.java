package com.app.controller;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class Cust_Login
 */
public class Cust_Login extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Cust_Login() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		Connection conn = null;
		String passwd = null;
		String fname =null;
		String lname = null;
		Long accnum =0L;
		Long usrid = 0L;
		
		try {

			String userName = request.getParameter("uname");
			System.out.println(userName);
			String passWord = request.getParameter("pwd");
			System.out.println(passWord);

			
			
			  Class.forName("com.mysql.jdbc.Driver"); conn =
			  DriverManager.getConnection("jdbc:mysql://localhost:3306/test", "root",
			  "root");
			 
			String sql = "SELECT PASSWORD FROM BANK_CUST_LOGIN_TAB WHERE USER_ID=?";
			PreparedStatement pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, userName);
			ResultSet rs = pstmt.executeQuery();
			while (rs.next()) {
				passwd = rs.getString("PASSWORD");
				System.out.println(passwd);
			}
			String sql1 = "select cp.FIRST_NAME,cp.LAST_NAME,cp.ACCOUNT_NUMBER,cl.USER_ID from BANK_CUST_PROFILE_TAB cp inner join BANK_CUST_LOGIN_TAB cl on cp.ACCOUNT_NUMBER=cl.ACCOUNT_NUMBER where cl.USER_ID=?";
			PreparedStatement pstmt2 = conn.prepareStatement(sql1);
			pstmt2.setString(1, userName);
			ResultSet rs1 = pstmt2.executeQuery();
			while (rs1.next()) {
				 fname = rs1.getString("FIRST_NAME");
				 lname = rs1.getString("LAST_NAME");
				 accnum = rs1.getLong("ACCOUNT_NUMBER");
				 usrid = rs1.getLong("USER_ID");
				System.out.println(fname);
				System.out.println(lname);
				System.out.println(accnum);
				System.out.println(usrid);
			}
			if (passWord.equals(passwd)) {
				System.out.println("Login Success!!");
		
				HttpSession session = request.getSession();
			      session.setAttribute("fname",fname);
			      session.setAttribute("lname",lname);
			      session.setAttribute("accnum",accnum );
			      session.setAttribute("usrid",usrid );
				
				RequestDispatcher rd = request.getRequestDispatcher("/Bank_HOME.jsp");
				rd.forward(request, response);
			} else {
				System.out.println("Login failed!!");
				request.setAttribute("errorMessage", "Invalid UserName or Password");
				
				RequestDispatcher rd = request.getRequestDispatcher("/Cust_Login.jsp");
				rd.forward(request, response);
			}	 
		} catch (Exception e) {
			e.printStackTrace();
		} 
			  finally { try { conn.close(); } catch (SQLException e) { e.printStackTrace();
			  } }
			 
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
