package com.app.controller;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class Cust_Txn_Acc_Display
 */
public class Cust_Txn_Acc_Display extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Cust_Txn_Acc_Display() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		
		
		
		Connection connection=null;
	      Double acc_bal=0.0d;
	      int i=0;
	      try {
	    	  
	    	  HttpSession session = request.getSession();
				Long acnm = (Long) session.getAttribute("accnum");
				
			  Class.forName("com.mysql.jdbc.Driver"); connection =
			  DriverManager.getConnection("jdbc:mysql://localhost:3306/test", "root",
			  "root");
			 
			System.out.println("Db connection opened!!");
			
			
			
			String sql1="select * from CUST_ACC_BAL_TAB where ACCOUNT_NUMBER=?";
		      PreparedStatement pstmt = connection.prepareStatement(sql1);
				pstmt.setLong(1, acnm);
				ResultSet rs = pstmt.executeQuery();
		      
				ArrayList a_List = new ArrayList();
				while (rs.next()) {
					ArrayList al = new ArrayList();
					al.add(rs.getLong("ACCOUNT_NUMBER"));
					al.add(rs.getDouble("ACCOUNT_BALANCE"));
					System.out.println("al :: " + al);
					
					a_List.add(al);
					
				}
				request.setAttribute("a_List", a_List);
				
				String sql2="select TRAN_ID,TRAN_DTTM,ACCOUNT_NUM,DESCRIPTION,DESCRIPTION1,WITHDRAWAL,DEPOSITS,ACC_BALANCE from CUST_TXN_TAB where ACCOUNT_NUM=? order by TRAN_DTTM desc LIMIT 5;";
				PreparedStatement pstmt1 = connection.prepareStatement(sql2);
				pstmt1.setLong(1, acnm);
				ResultSet rs1 = pstmt1.executeQuery();
				
				ArrayList a_List1 = new ArrayList();
				while (rs1.next()) {
					ArrayList al1 = new ArrayList();
					al1.add(rs1.getLong("TRAN_ID"));
					al1.add(rs1.getTimestamp("TRAN_DTTM"));
					al1.add(rs1.getLong("ACCOUNT_NUM"));
					al1.add(rs1.getString("DESCRIPTION")+" /"+rs1.getString("DESCRIPTION1"));
					al1.add(rs1.getDouble("WITHDRAWAL"));
					al1.add(rs1.getDouble("DEPOSITS"));
					al1.add(rs1.getDouble("ACC_BALANCE"));
				
					System.out.println("al1 :: " + al1);
					a_List1.add(al1);
					
				}
					request.setAttribute("a_List1", a_List1);
			  
			  RequestDispatcher rd = request.getRequestDispatcher("/Cust_Txn_Acc_Display.jsp");
			  rd.forward(request, response);
			
			  
		      }catch (Exception e) {
				e.printStackTrace();
			}finally {
				try {
					connection.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
	
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
