package com.app.controller;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class Cust_Profile
 */
public class Cust_Profile extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Cust_Profile() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		Connection conn = null;
		/*
		 * String fname=null; String lname=null; //Date dob=null; Long mobnum=0L; Long
		 * accnum=0L; Long userid=0L; String branchname=null;
		 */
		try {

			HttpSession session = request.getSession();
			Long acnm = (Long) session.getAttribute("accnum");
		
			
			
			  Class.forName("com.mysql.jdbc.Driver"); conn =
			  DriverManager.getConnection("jdbc:mysql://localhost:3306/test", "root",
			  "root");
			 
			String sql = "select cp.FIRST_NAME,cp.LAST_NAME,cp.DATE_OF_BIRTH,cp.MOBILE_NUMBER,cp.ACCOUNT_NUMBER,cl.USER_ID,cp.BRANCH_NAME from BANK_CUST_PROFILE_TAB cp inner join BANK_CUST_LOGIN_TAB cl on cp.ACCOUNT_NUMBER=cl.ACCOUNT_NUMBER where cp.ACCOUNT_NUMBER=?";
			PreparedStatement pstmt = conn.prepareStatement(sql);
			pstmt.setLong(1, acnm);
			ResultSet rs = pstmt.executeQuery();
			
			ArrayList a_List = new ArrayList();
			while (rs.next()) {
				ArrayList al = new ArrayList();
				al.add(rs.getString("FIRST_NAME")+" "+rs.getString("LAST_NAME"));
				al.add(rs.getDate("DATE_OF_BIRTH"));
				al.add(rs.getLong("MOBILE_NUMBER"));
				al.add(rs.getLong("ACCOUNT_NUMBER"));
				al.add(rs.getLong("USER_ID"));
				al.add(rs.getString("BRANCH_NAME"));
				
				System.out.println("al :: " + al);
				a_List.add(al);	
			}
			request.setAttribute("a_List", a_List);
	
			RequestDispatcher rd = request.getRequestDispatcher("/Cust_Profile.jsp");
			rd.forward(request, response);
			
		}catch (Exception e) {
			e.printStackTrace();
		}finally {
			try {
				conn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
