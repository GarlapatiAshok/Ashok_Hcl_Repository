package com.app.controller;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class Cust_Register
 */
public class Cust_Register extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Cust_Register() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		
		Connection conn = null;
		int i1 = 0,i2=0,i3=0,i4=0;
		String userId = null;
		String acc_num=null;
		try {

			String firstName = request.getParameter("firstname");
			String lastName = request.getParameter("lastname");
			String fatherName = request.getParameter("fathername");
			String gender = request.getParameter("gender");
			String language="";
			String lang[]=request.getParameterValues("language");
			for(int i=0;i<lang.length;i++){
				language+=lang[i]+" ";
	        }
			System.out.println(language);
			String branchName = request.getParameter("branchname");
			String dob = request.getParameter("dob");
			String presentAddr = request.getParameter("presentaddress");
			String permenantAddr = request.getParameter("permanentaddress");
			String email = request.getParameter("email");
			String mobileNumber = request.getParameter("mobilenumber");
			long mobileNum = Long.parseLong(mobileNumber);
			String passWord = request.getParameter("password");
			
			
			  Class.forName("com.mysql.jdbc.Driver"); conn =
			  DriverManager.getConnection("jdbc:mysql://localhost:3306/test", "root",
			  "root");
			 
			String sql="INSERT INTO BANK_CUST_PROFILE_TAB(FIRST_NAME,LAST_NAME,FATHER_NAME,GENDER,LANGUAGE,BRANCH_NAME,DATE_OF_BIRTH,PRESENT_ADDRESS,PERMINANT_ADDRESS,EMAIL_ID,MOBILE_NUMBER) VALUES(?,?,?,?,?,?,str_to_date(?,'%Y-%m-%d'),?,?,?,?)";
			PreparedStatement pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, firstName);
			pstmt.setString(2, lastName);
			pstmt.setString(3, fatherName);
			pstmt.setString(4, gender);
			pstmt.setString(5, language);
			pstmt.setString(6, branchName);
			pstmt.setString(7, dob);
			pstmt.setString(8, presentAddr);
			pstmt.setString(9, permenantAddr);
			pstmt.setString(10, email);
			pstmt.setLong(11, mobileNum);
			i1 = pstmt.executeUpdate();
			System.out.println(i1);
			
			
String sql1="INSERT INTO BANK_CUST_LOGIN_TAB(PASSWORD) VALUES(?)";
PreparedStatement pstmt1 = conn.prepareStatement(sql1);
pstmt1.setString(1, passWord);
i2 = pstmt1.executeUpdate();
System.out.println(i2);

String sql3="SELECT ACCOUNT_NUMBER FROM BANK_CUST_PROFILE_TAB order by ACCOUNT_NUMBER asc";
PreparedStatement pstmt4 = conn.prepareStatement(sql3);
ResultSet rs1 = pstmt4.executeQuery();
while (rs1.next()) {
	acc_num = rs1.getString("ACCOUNT_NUMBER");
	System.out.println(acc_num);
}

String sql5="INSERT INTO CUST_ACC_BAL_TAB(ACCOUNT_NUMBER) VALUES(?)";
PreparedStatement pstmt6 = conn.prepareStatement(sql5);
pstmt6.setString(1, acc_num);
i4 = pstmt6.executeUpdate();
System.out.println(i4);

String sql2="SELECT USER_ID FROM BANK_CUST_LOGIN_TAB order by USER_ID asc";
PreparedStatement pstmt3 = conn.prepareStatement(sql2);
ResultSet rs2 = pstmt3.executeQuery();
while (rs2.next()) {
	userId = rs2.getString("USER_ID");
	System.out.println(userId);
}

String sql4="UPDATE BANK_CUST_LOGIN_TAB SET ACCOUNT_NUMBER="+acc_num+" WHERE USER_ID="+userId+"";
Statement stmt = conn.createStatement();
i3 = stmt.executeUpdate(sql4);
System.out.println(i3);

			String msg = "";
			if (i1 != 0 && i2 !=0) {
				msg = "YOU HAVE SUCCESSFULLY CREATED BANK ACCOUNT IN ROYAL BANK..YOU USER ID IS: "+userId+" AND YOUR BANK ACCOUNT NUMBER IS: "+acc_num+"";
			} else {
				msg = "YOU ARE NOT ELGIBLE TO CREATE AN ACCOUNT IN ROYAL BANK!!";
			}
			request.setAttribute("message", msg);
			
			RequestDispatcher rd = request.getRequestDispatcher("/Cust_Login.jsp");
			rd.forward(request, response);

			
		} catch (Exception e) {
			e.printStackTrace();
		} finally {

			try {
				if (i1 != 0 && i2 !=0) {
					conn.close();
					System.out.println("DATABASE CONNECTION CLOSED!!");
				} else {
					System.out.println("DATABASE CONNECTION NOT CLOSED!!");
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();

			}
		}

		
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
