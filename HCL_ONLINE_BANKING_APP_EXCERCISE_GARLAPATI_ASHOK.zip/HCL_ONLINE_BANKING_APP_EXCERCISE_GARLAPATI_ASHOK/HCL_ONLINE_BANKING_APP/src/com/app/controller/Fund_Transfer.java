package com.app.controller;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class Fund_Transfer
 */
public class Fund_Transfer extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Fund_Transfer() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
	    ArrayList fromList = new ArrayList();
		ArrayList toList = new ArrayList();
		ArrayList arrList = new ArrayList();
	String from_accno=request.getParameter("frm_acc_num");
	System.out.println(from_accno);
	String to_accno=request.getParameter("to_acc_num");
	System.out.println(to_accno);
	String amount=request.getParameter("amt");
	Double amtt=Double.parseDouble(amount);
	System.out.println(amtt);
	String remarks=request.getParameter("remarks");
	System.out.println(remarks);
	

	Connection connection = null;
	PreparedStatement stmt=null, stmt1 = null,stmt10 = null;
	Statement stmt2,stmt3,stmt4 = null;
	int i4=0,i5=0,i6=0;
	try {
		
			  Class.forName("com.mysql.jdbc.Driver"); connection =
			  DriverManager.getConnection("jdbc:mysql://localhost:3306/test", "root",
			  "root");
			 
		System.out.println("Db connection opened!!");
	
		String query1 = "SELECT * FROM CUST_ACC_BAL_TAB where ACCOUNT_NUMBER ='"+from_accno.trim()+"'" ;
		System.out.println("query " + query1);
		stmt1 = connection.prepareStatement(query1);
		ResultSet rs1 = stmt1.executeQuery();
		if(rs1.next()) {
			ArrayList arrRow = new ArrayList();
			arrRow.add(rs1.getString("ACCOUNT_NUMBER"));
			arrRow.add(rs1.getString("ACCOUNT_BALANCE"));
			arrList.add(arrRow);
		}
		fromList = (ArrayList)arrList.get(0);
		System.out.println(fromList);
	
		//fromList = (ArrayList)arrList.get(1);
		
		String query10 = "SELECT * FROM CUST_ACC_BAL_TAB where ACCOUNT_NUMBER ='"+to_accno.trim()+"'" ;
		System.out.println("query " + query10);
		stmt10 = connection.prepareStatement(query10);
		ResultSet rs5 = stmt10.executeQuery();
		if(rs5.next()) {
			ArrayList arrRow = new ArrayList();
			arrRow.add(rs5.getString("ACCOUNT_NUMBER"));
			arrRow.add(rs5.getString("ACCOUNT_BALANCE"));
			arrList.add(arrRow);
		}
		toList = (ArrayList)arrList.get(0);
		System.out.println(toList);
	
		toList = (ArrayList)arrList.get(1);
		
			
		
		if(Double.parseDouble((String)fromList.get(1))>=amtt) {
			double FromTotal = Double.parseDouble((String)fromList.get(1))-amtt;
			double toTotal = Double.parseDouble((String)toList.get(1))+amtt;
			System.out.println(FromTotal);
			
			String query2 = "UPDATE CUST_ACC_BAL_TAB SET ACCOUNT_BALANCE='"+FromTotal+"' WHERE ACCOUNT_NUMBER='"+from_accno.trim()+"'";
			String query3 = "UPDATE CUST_ACC_BAL_TAB SET ACCOUNT_BALANCE='"+toTotal+"' WHERE ACCOUNT_NUMBER='"+to_accno.trim()+"'";
			System.out.println("query"+query2);
			System.out.println("query"+query3);
			stmt2=connection.createStatement();
			stmt3=connection.createStatement();
			 i5=stmt2.executeUpdate(query2);
			 i6=stmt3.executeUpdate(query3);
			System.out.println("test........");
			 if(i5!=0 && i6!=0) {
				 
				 
				 HttpSession session = request.getSession();
			      session.setAttribute("facc",from_accno);
			      session.setAttribute("tacc",to_accno);
			      session.setAttribute("amtt",amtt);
			      session.setAttribute("remarks",remarks);
			      session.setAttribute("ft",FromTotal);
			      session.setAttribute("tt",toTotal);
				 
				  RequestDispatcher rd = request.getRequestDispatcher("/Cust_Txn");
				  rd.forward(request, response);
				 
			 }else {
					/*
					 * String msg1="INVALID DATA!!.."; request.setAttribute("errmsg1", msg1);
					 * 
					 * RequestDispatcher rd = request.getRequestDispatcher("/Fund_Transfer.jsp");
					 * rd.forward(request, response);
					 */
				 
				 System.out.println("inf..");
			 }	
		}
		
		else {

				/*
				 * String msg="INSUFFICIENT FUNDS!!.."; request.setAttribute("errmsg", msg);
				 * 
				 * RequestDispatcher rd = request.getRequestDispatcher("/Fund_Transfer.jsp");
				 * rd.forward(request, response);
				 */
			 System.out.println("inf..");
		}
		
		
	}catch (Exception e) {
		// TODO: handle exception
	}	
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
